from sqlalchemy.orm import Session
from database.connection import SessionLocal
from database.models import User

from factories.user_factory import UserFactory
from strategies.sha256_strategy import SHA256Strategy
from decorators.log_decorator import log_action

from observers.user_subject import UserSubject
from observers.email_observer import EmailObserver
from observers.logger_observer import LoggerObserver

import secrets
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

SMTP_EMAIL = "wbills.app.co@gmail.com"
SMTP_PASS  = "aonb avii vpqg nzrx"
SMTP_HOST  = "smtp.gmail.com"
SMTP_PORT  = 587

# Almacén temporal de tokens de recuperacion (en produccion usar Redis/DB)
_reset_tokens: dict = {}


class AuthService:

    def __init__(self):
        self.db: Session = SessionLocal()
        self.hash_strategy = SHA256Strategy()
        self.subject = UserSubject()
        self.subject.attach(EmailObserver())
        self.subject.attach(LoggerObserver())

    def valid_email(self, email):
        pattern = r"^[\w\.\-]+@[\w\.\-]+\.[a-zA-Z]{2,}$"
        return re.match(pattern, email) is not None

    def valid_username(self, name):
        return len(name) >= 3

    def valid_password(self, password):
        return (
            len(password) >= 8
            and any(c.isupper() for c in password)
            and any(c.isdigit() for c in password)
        )

    def _send_email(self, to_addr: str, subject: str, body_html: str) -> bool:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = SMTP_EMAIL
            msg["To"] = to_addr
            msg.attach(MIMEText(body_html, "html", "utf-8"))
            with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
                server.ehlo()
                server.starttls()
                server.login(SMTP_EMAIL, SMTP_PASS)
                server.sendmail(SMTP_EMAIL, to_addr, msg.as_string())
            return True
        except Exception as e:
            print(f"[EMAIL ERROR] {e}")
            return False

    @log_action
    def register(self, data):
        if not self.valid_email(data.email):
            return {"error": "Correo invalido. Debe tener un dominio valido (ej: usuario@dominio.com)"}

        if not self.valid_username(data.name):
            return {"error": "El nombre debe tener al menos 3 caracteres"}

        if not self.valid_password(data.password):
            return {"error": "La contrasena debe tener 8 caracteres, una mayuscula y un numero"}

        existing_user = (
            self.db.query(User)
            .filter(User.email == data.email)
            .first()
        )
        if existing_user:
            return {"error": "Ya existe una cuenta con ese correo"}

        hashed_password = self.hash_strategy.hash(data.password)
        user_data = UserFactory.create(data.name, data.email, hashed_password)

        new_user = User(
            name=user_data["name"],
            email=user_data["email"],
            password=user_data["password"]
        )
        self.db.add(new_user)
        self.db.commit()
        self.db.refresh(new_user)
        self.subject.notify(user_data)
        return {"message": "Usuario registrado"}

    @log_action
    def login(self, data):
        user = (
            self.db.query(User)
            .filter(User.email == data.email)
            .first()
        )
        if not user:
            return {"error": "Usuario no encontrado"}

        hashed_password = self.hash_strategy.hash(data.password)
        if user.password != hashed_password:
            return {"error": "Contrasena incorrecta"}

        token = secrets.token_hex(32)
        return {
            "access_token": token,
            "user": {"name": user.name, "email": user.email}
        }

    def request_password_reset(self, email: str):
        if not self.valid_email(email):
            return {"error": "Correo invalido"}

        user = self.db.query(User).filter(User.email == email).first()
        # Respondemos igual aunque no exista (seguridad)
        if not user:
            return {"message": "Si el correo esta registrado, recibiras un enlace en tu bandeja."}

        token = secrets.token_urlsafe(32)
        _reset_tokens[token] = email

        reset_link = f"https://wbills.app/reset-password?token={token}"

        body = f"""
        <div style="font-family:sans-serif;max-width:480px;margin:auto;padding:32px;background:#0d0d0d;color:#f0e6d0;border-radius:12px">
          <h2 style="color:#C9A84C;margin-bottom:8px">WBill$ — Recuperar contrasena</h2>
          <p>Hola <strong>{user.name}</strong>,</p>
          <p>Recibimos una solicitud para restablecer la contrasena de tu cuenta.</p>
          <p>Haz clic en el boton para continuar:</p>
          <a href="{reset_link}"
             style="display:inline-block;margin:16px 0;padding:12px 28px;background:#C9A84C;color:#0d0d0d;border-radius:8px;text-decoration:none;font-weight:700">
            Restablecer contrasena
          </a>
          <p style="font-size:12px;color:#888">Este enlace expira en 30 minutos.<br>Si no solicitaste esto, ignora este mensaje.</p>
        </div>
        """

        sent = self._send_email(email, "WBill$ — Recupera tu contrasena", body)
        if sent:
            return {"message": "Si el correo esta registrado, recibiras un enlace en tu bandeja."}
        else:
            return {"error": "No se pudo enviar el correo. Intenta mas tarde."}

    def change_password(self, email: str, old_password: str, new_password: str):
        user = self.db.query(User).filter(User.email == email).first()
        if not user:
            return {"error": "Usuario no encontrado"}

        hashed_old = self.hash_strategy.hash(old_password)
        if user.password != hashed_old:
            return {"error": "La contrasena actual es incorrecta"}

        if not self.valid_password(new_password):
            return {"error": "La nueva contrasena debe tener 8 caracteres, una mayuscula y un numero"}

        user.password = self.hash_strategy.hash(new_password)
        self.db.commit()
        return {"message": "Contrasena actualizada correctamente"}
