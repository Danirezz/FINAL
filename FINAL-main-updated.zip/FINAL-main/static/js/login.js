/* ─── Validacion de email real con dominio ─── */
function isValidEmail(email){
  // Requiere usuario + @ + dominio + . + TLD de al menos 2 chars
  return /^[\w.\-]+@[\w.\-]+\.[a-zA-Z]{2,}$/.test(email.trim());
}

/* ─── Demo ─── */
const DEMO = { email: 'demo@wbills.co', password: 'Demo1234', name: 'Usuario Demo' };

function goDemo(){
  sessionStorage.setItem('wbills_token','demo-token-wbills');
  sessionStorage.setItem('wbills_user',JSON.stringify({name:DEMO.name,email:DEMO.email}));
  window.location.href='/dashboard';
}

/* ─── Tabs ─── */
function switchTab(t){
  document.querySelectorAll('.tab').forEach((el,i)=>
    el.classList.toggle('active',(t==='login'&&i===0)||(t==='registro'&&i===1))
  );
  document.getElementById('form-login').style.display   = t==='login'   ?'flex':'none';
  document.getElementById('form-registro').style.display = t==='registro'?'flex':'none';
  hideAlert();
}

/* ─── Alertas ─── */
function showAlert(m,t='err'){
  const el=document.getElementById('alert');
  el.textContent=(t==='err'?'⚠ ':'✓ ')+m;
  el.className='alert show '+t;
}
function hideAlert(){document.getElementById('alert').className='alert';}

/* ─── Loading ─── */
function setLoad(b,s,t,l){
  document.getElementById(b).disabled=l;
  document.getElementById(s).style.display=l?'block':'none';
  document.getElementById(t).style.display=l?'none':'inline';
}

/* ─── Login ─── */
async function doLogin(){
  const email = document.getElementById('l-email').value.trim();
  const pass  = document.getElementById('l-pass').value;

  if(!email||!pass) return showAlert('Por favor completa todos los campos.');

  if(!isValidEmail(email))
    return showAlert('Ingresa un correo valido con dominio (ej: usuario@gmail.com).');

  hideAlert();
  setLoad('btn-login','login-spin','login-txt',true);

  // Demo
  if(email===DEMO.email && pass===DEMO.password){
    sessionStorage.setItem('wbills_token','demo-token-wbills');
    sessionStorage.setItem('wbills_user',JSON.stringify({name:DEMO.name,email:DEMO.email}));
    showAlert('Bienvenido, '+DEMO.name+'!','ok');
    setTimeout(()=>{ window.location.href='/dashboard'; },900);
    setLoad('btn-login','login-spin','login-txt',false);
    return;
  }

  try{
    const res  = await fetch('/api/login',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email, password:pass})
    });
    const data = await res.json();
    if(res.ok){
      // sessionStorage -> se borra al cerrar/recargar
      sessionStorage.setItem('wbills_token', data.access_token);
      sessionStorage.setItem('wbills_user',  JSON.stringify(data.user));
      showAlert('Bienvenido, '+data.user.name+'!','ok');
      setTimeout(()=>{ window.location.href='/dashboard'; },900);
    } else {
      showAlert(data.detail || data.error || 'Correo o contrasena incorrectos.');
    }
  }catch(e){
    console.error(e);
    showAlert('Error de conexion con el servidor.');
  }
  setLoad('btn-login','login-spin','login-txt',false);
}

/* ─── Registro ─── */
async function doReg(){
  const name  = document.getElementById('r-name').value.trim();
  const email = document.getElementById('r-email').value.trim();
  const pass  = document.getElementById('r-pass').value;
  const pass2 = document.getElementById('r-pass2').value;

  if(!name||!email||!pass||!pass2) return showAlert('Por favor completa todos los campos.');

  if(!isValidEmail(email))
    return showAlert('Ingresa un correo valido con dominio (ej: usuario@gmail.com).');

  if(pass.length<8) return showAlert('La contrasena debe tener minimo 8 caracteres.');
  if(pass!==pass2)  return showAlert('Las contrasenas no coinciden.');

  hideAlert();
  setLoad('btn-reg','reg-spin','reg-txt',true);

  try{
    const res  = await fetch('/api/register',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name, email, password:pass})
    });
    const data = await res.json();
    if(res.ok){
      showAlert('Cuenta creada. Inicia sesion ahora.','ok');
      setTimeout(()=>{ switchTab('login'); hideAlert(); document.getElementById('l-email').value=email; },1400);
    } else {
      showAlert(data.detail || data.error || 'Error al crear la cuenta.');
    }
  }catch(e){
    showAlert('No se pudo conectar con el servidor.');
  }
  setLoad('btn-reg','reg-spin','reg-txt',false);
}

/* ─── Indicador de fuerza ─── */
function checkStr(val){
  const sw=document.getElementById('sw');
  sw.classList.toggle('show',val.length>0);
  let sc=0;
  if(val.length>=8)            sc++;
  if(/[A-Z]/.test(val))        sc++;
  if(/[0-9]/.test(val))        sc++;
  if(/[^A-Za-z0-9]/.test(val)) sc++;
  const cols=['#FF6B6B','#FF6B6B','#C9A84C','#4ECDC4'];
  const lbls=['Muy debil','Debil','Aceptable','Fuerte'];
  for(let i=1;i<=4;i++)
    document.getElementById('s'+i).style.background = i<=sc ? cols[sc-1] : 'var(--s2)';
  document.getElementById('slbl').textContent = val.length>0 ? lbls[Math.max(0,sc-1)] : '';
}

/* ─── Modal recuperar contrasena ─── */
function openResetModal(){
  document.getElementById('reset-modal').classList.add('show');
  document.getElementById('reset-email').value='';
  document.getElementById('reset-msg').textContent='';
  document.getElementById('reset-msg').className='modal-msg';
}
function closeResetModal(){
  document.getElementById('reset-modal').classList.remove('show');
}

async function doReset(){
  const email = document.getElementById('reset-email').value.trim();
  const msgEl = document.getElementById('reset-msg');
  const btn   = document.getElementById('btn-reset');
  const spin  = document.getElementById('reset-spin');

  if(!email){
    msgEl.textContent='Ingresa tu correo.';
    msgEl.className='modal-msg err';
    return;
  }
  if(!isValidEmail(email)){
    msgEl.textContent='El correo no tiene un formato valido (ej: usuario@gmail.com).';
    msgEl.className='modal-msg err';
    return;
  }

  btn.disabled=true;
  spin.style.display='inline-block';
  msgEl.textContent='Enviando...';
  msgEl.className='modal-msg';

  try{
    const res  = await fetch('/api/reset-password-request',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email})
    });
    const data = await res.json();
    if(data.error){
      msgEl.textContent=data.error;
      msgEl.className='modal-msg err';
    } else {
      msgEl.textContent='✓ Revisa tu bandeja de entrada.';
      msgEl.className='modal-msg ok';
      setTimeout(closeResetModal, 3000);
    }
  }catch(e){
    msgEl.textContent='No se pudo conectar con el servidor.';
    msgEl.className='modal-msg err';
  }

  btn.disabled=false;
  spin.style.display='none';
}

/* ─── Cerrar modal con Escape ─── */
document.addEventListener('keydown', e=>{
  if(e.key==='Escape') closeResetModal();
  if(e.key==='Enter'){
    const modal = document.getElementById('reset-modal');
    if(modal.classList.contains('show')){ doReset(); return; }
    const tab = document.querySelector('.tab.active').textContent;
    if(tab.includes('sesión')) doLogin(); else doReg();
  }
});
