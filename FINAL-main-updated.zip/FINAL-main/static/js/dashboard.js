document.addEventListener('DOMContentLoaded', () => {

/* ─── PROTECCION: sessionStorage se borra al cerrar/recargar ─── */
const token = sessionStorage.getItem('wbills_token');
if(!token){ window.location.href = '/'; }

/* ─── Menu de usuario ─── */
function toggleUserMenu(){
  const m = document.getElementById('user-menu');
  m.style.display = m.style.display==='block' ? 'none' : 'block';
}
document.addEventListener('click', e=>{
  const menu = document.getElementById('user-menu');
  const av   = document.getElementById('topav');
  if(menu && !menu.contains(e.target) && e.target!==av){
    menu.style.display='none';
  }
});
function doLogout(){
  sessionStorage.removeItem('wbills_token');
  sessionStorage.removeItem('wbills_user');
  window.location.href='/';
}
function openChangePwd(){
  document.getElementById('user-menu').style.display='none';
  ['cp-old','cp-new','cp-new2'].forEach(id=>document.getElementById(id).value='');
  const msg=document.getElementById('cp-msg');
  msg.textContent=''; msg.style.color='';
  document.getElementById('chpwd-modal').style.display='flex';
}
function closeChangePwd(){
  document.getElementById('chpwd-modal').style.display='none';
}
async function doChangePwd(){
  const old_  = document.getElementById('cp-old').value;
  const newp  = document.getElementById('cp-new').value;
  const newp2 = document.getElementById('cp-new2').value;
  const msg   = document.getElementById('cp-msg');
  const btn   = document.getElementById('cp-btn');
  const u     = JSON.parse(sessionStorage.getItem('wbills_user')||'{}');
  if(!old_||!newp||!newp2){ msg.textContent='Completa todos los campos.'; msg.style.color='#E05555'; return; }
  if(newp!==newp2){ msg.textContent='Las contrasenas no coinciden.'; msg.style.color='#E05555'; return; }
  if(newp.length<8||!/[A-Z]/.test(newp)||!/[0-9]/.test(newp)){
    msg.textContent='Min 8 chars, 1 mayuscula y 1 numero.'; msg.style.color='#E05555'; return;
  }
  btn.disabled=true; msg.textContent='Guardando...'; msg.style.color='#888';
  try{
    const res  = await fetch('/api/change-password',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email:u.email, old_password:old_, new_password:newp})
    });
    const data = await res.json();
    if(data.error){ msg.textContent=data.error; msg.style.color='#E05555'; }
    else{ msg.textContent='Contrasena actualizada. Redirigiendo...'; msg.style.color='#4ECDC4'; setTimeout(doLogout,2000); }
  }catch(e){ msg.textContent='Error de conexion.'; msg.style.color='#E05555'; }
  btn.disabled=false;
}
document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeChangePwd(); });
window.toggleUserMenu=toggleUserMenu;
window.doLogout=doLogout;
window.openChangePwd=openChangePwd;
window.closeChangePwd=closeChangePwd;
window.doChangePwd=doChangePwd;

/* ─── DATA ─── */
const CATS=[{n:'Alimentacion',e:'🍔'},{n:'Transporte',e:'🚌'},{n:'Ocio',e:'🎬'},{n:'Salud',e:'🏥'},{n:'Educacion',e:'📚'},{n:'Salario',e:'💼'}];
let uCats=[...CATS],selCat=null,tipo=null,totIng=4500000,totGas=80600;

/* ─── STORAGE ─── */
function saveData(){
  localStorage.setItem('wbills_data', JSON.stringify({totIng,totGas,uCats}));
}
function loadData(){
  const d=JSON.parse(localStorage.getItem('wbills_data')||'{}');
  if(d.totIng) totIng=d.totIng;
  if(d.totGas) totGas=d.totGas;
  if(d.uCats)  uCats=d.uCats;
}
loadData();

/* ─── FECHA ─── */
const today=new Date().toISOString().split('T')[0];
document.getElementById('f-fecha').value=today;

/* ─── KPIs ─── */
function upKPIs(){
  const b=totIng-totGas;
  document.getElementById('king').textContent='$'+totIng.toLocaleString('es-CO');
  document.getElementById('kgas').textContent='$'+totGas.toLocaleString('es-CO');
  document.getElementById('kbal').textContent='$'+b.toLocaleString('es-CO');
}
upKPIs();

/* ─── USUARIO ─── */
try{
  const u=JSON.parse(sessionStorage.getItem('wbills_user')||'{}');
  if(u.name){
    const n=u.name.split(' ')[0];
    document.getElementById('wname').textContent=n;
    document.getElementById('topuser').textContent='Hola, '+n;
    document.getElementById('topav').textContent=n.substring(0,2).toUpperCase();
  }
  if(u.email) document.getElementById('menu-email').textContent=u.email;
}catch(e){}

/* ─── UI ─── */
function selectTipo(t){
  tipo=t;
  document.getElementById('btn-ing').className='abtn'+(t==='ingreso'?' active-sel':'');
  document.getElementById('btn-gas').className='abtn'+(t==='gasto'?' active-sel':'');
  document.getElementById('form-ttl').textContent=t==='ingreso'?'↑ Registrar Ingreso':'↓ Registrar Gasto';
  document.getElementById('mov-form').classList.add('open');
  document.getElementById('af').className='af';
}

function fmtMonto(inp){
  let v=inp.value.replace(/\D/g,'');
  inp.value=v?'$'+parseInt(v).toLocaleString('es-CO'):'';
}

/* ─── CATEGORIAS ─── */
function buildCatSel(){
  const c=document.getElementById('cat-sel');
  c.innerHTML='';
  uCats.forEach((cat,i)=>{
    const d=document.createElement('div');
    d.className='cs'+(selCat===i?' sel':'');
    d.innerHTML='<div class="cs-ico">'+cat.e+'</div><div style="font-size:10px">'+cat.n+'</div>';
    d.onclick=()=>{ selCat=i; buildCatSel(); document.getElementById('nc-form').classList.remove('open'); };
    c.appendChild(d);
  });
}
buildCatSel();

function addCat(){
  const n=document.getElementById('nc-name').value.trim();
  const e=document.getElementById('nc-emoji').value.trim()||'🏷️';
  if(!n)return;
  uCats.push({n,e});
  selCat=uCats.length-1;
  document.getElementById('nc-name').value='';
  document.getElementById('nc-emoji').value='';
  buildCatSel();
  saveData();
}

/* ─── GUARDAR ─── */
function guardar(){
  const raw=document.getElementById('f-monto').value.replace(/\D/g,'');
  const desc=document.getElementById('f-desc').value.trim();
  const fecha=document.getElementById('f-fecha').value;
  const af=document.getElementById('af');
  if(!tipo){ af.textContent='⚠ Selecciona tipo.'; af.className='af err'; return; }
  if(selCat===null){ af.textContent='⚠ Selecciona categoria.'; af.className='af err'; return; }
  if(!raw){ af.textContent='⚠ Ingresa monto.'; af.className='af err'; return; }
  const v=parseInt(raw);
  if(tipo==='ingreso') totIng+=v; else totGas+=v;
  upKPIs(); saveData();
  af.textContent='✓ Guardado'; af.className='af ok';
  document.getElementById('f-monto').value='';
  document.getElementById('f-desc').value='';
  selCat=null; buildCatSel();
}

/* ─── CHARTS ─── */
if(typeof Chart !== 'undefined'){ console.log('Chart.js OK'); }
else{ console.warn('Chart.js no cargo'); }

});
